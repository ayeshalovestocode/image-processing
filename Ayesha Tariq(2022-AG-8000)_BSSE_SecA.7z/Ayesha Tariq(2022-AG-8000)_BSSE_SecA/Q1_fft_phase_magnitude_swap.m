% Q1: FFT Magnitude and Phase Swap using 'peppers.png' and 'saturn.png'
% Read two grayscale images
img1 = rgb2gray(imread('peppers.png'));
img2 = rgb2gray(imread('saturn.png'));

% Convert to double
img1 = im2double(img1);
img2 = im2double(img2);

% Resize images to same size
img2 = imresize(img2, size(img1));

% FFT of both images
fft1 = fft2(img1);
fft2 = fft2(img2);

% Magnitude and Phase
mag1 = abs(fft1);
phase1 = angle(fft1);
mag2 = abs(fft2);
phase2 = angle(fft2);

% Reconstruct by swapping phase and magnitude
recon1 = abs(fft1).*exp(1i*phase2);
recon2 = abs(fft2).*exp(1i*phase1);

% Inverse FFT
out1 = real(ifft2(recon1));
out2 = real(ifft2(recon2));

% Display all
figure;
subplot(3,4,1); imshow(img1); title('Peppers');
subplot(3,4,2); imshow(log(1+mag1),[]); title('Magnitude 1');
subplot(3,4,3); imshow(phase1,[]); title('Phase 1');
subplot(3,4,4); imshow(out2,[]); title('Mag1 + Phase2');

subplot(3,4,5); imshow(img2); title('Saturn');
subplot(3,4,6); imshow(log(1+mag2),[]); title('Magnitude 2');
subplot(3,4,7); imshow(phase2,[]); title('Phase 2');
subplot(3,4,8); imshow(out1,[]); title('Mag2 + Phase1');
