% count_circles.m
% Accurate detection of solid colored circles in the provided image

% Read image
img = imread('circles.jpg');

% Convert to HSV color space
hsv_img = rgb2hsv(img);
sat = hsv_img(:,:,2); % Saturation channel
val = hsv_img(:,:,3); % Value channel

% Create a binary mask to isolate colorful regions (ignore white)
mask = sat > 0.4 & val > 0.5;

% Clean up the mask
mask = bwareaopen(mask, 500);      % Remove small objects
mask = imfill(mask, 'holes');      % Fill inside circles

% Label connected components and measure properties
stats = regionprops(mask, 'Area', 'Eccentricity', 'BoundingBox', 'Centroid');

% Display original image
imshow(img); hold on;

% Initialize count
circle_count = 0;

% Loop through regions and count circular ones
for k = 1:length(stats)
    if stats(k).Eccentricity < 0.7 % threshold for round shapes
        rectangle('Position', stats(k).BoundingBox, 'EdgeColor', 'g', 'LineWidth', 2);
        circle_count = circle_count + 1;
    end
end

% Display total count
title(['Total Circles Detected: ', num2str(circle_count)]);
